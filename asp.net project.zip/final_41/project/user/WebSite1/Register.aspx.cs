﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Contack_Us : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblmsg.Text = "";
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        lblmsg.Text = "";
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
        TextBox8.Text = "";
        TextBox9.Text = "";


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection Con = new SqlConnection(ConfigurationManager.ConnectionStrings["abc"].ConnectionString);
        SqlCommand com = Con.CreateCommand();
        com.CommandText = "insert into register_user (user_nm,user_fnm,Eid,pwd,content_no,Address,city,pincode) values(@user_nm,@user_fnm,@Eid,@pwd,@content_no,@Address,@city,@pincode)";
       
        com.Parameters.AddWithValue("@user_nm",TextBox1.Text);
        com.Parameters.AddWithValue("@user_fnm",TextBox2.Text);
       
        com.Parameters.AddWithValue("@Eid",TextBox4.Text);
        com.Parameters.AddWithValue("@pwd",TextBox5.Text);
        com.Parameters.AddWithValue("@content_no",TextBox6.Text);
        com.Parameters.AddWithValue("@Address",TextBox7.Text);
        com.Parameters.AddWithValue("@city",TextBox8.Text);
        com.Parameters.AddWithValue("@pincode",TextBox9.Text);

        Con.Open();

        //int res=com.ExecuteNonQuery();
        Con.Close();

      //  if(res>0)
       // {
        //    lblmsg.Text="record inserted successfully";
         
       // }
       // else
        //{
         //   lblmsg.Text="could not insert record";
          //  TextBox1.Text = "";
           // TextBox2.Text = "";
            //TextBox4.Text = "";
            //TextBox5.Text = "";
           // TextBox6.Text = "";
           // TextBox7.Text = "";
            //TextBox8.Text = "";
            //TextBox9.Text = "";


            }
      

}

