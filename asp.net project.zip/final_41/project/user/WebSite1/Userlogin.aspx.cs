﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Userlogin : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security=True;User Instance=True");
        con.Open();

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        com=con.CreateCommand();
        com.CommandText="select * from Register_user where user_nm=' "+TextBox1.Text+" ' and pwd='"+TextBox2.Text+ " ' ";

        dr=com.ExecuteReader();
        if(dr.Read())
        {
            Session["user_nm"]=TextBox1.Text;
            Response.Redirect("Product.aspx");
        }
        else
        {
            Response.Write(" data not found");
        }
    
    }
}
