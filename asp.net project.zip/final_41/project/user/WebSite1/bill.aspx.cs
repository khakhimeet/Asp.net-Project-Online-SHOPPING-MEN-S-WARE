﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class bill : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
                                                       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection Con = new SqlConnection(ConfigurationManager.ConnectionStrings["abc"].ConnectionString);
        SqlCommand com = Con.CreateCommand();
        com.CommandText = "insert into bill(username,emailid,address,productname,price,quantity,totalcost) values(@username,@emailid,@address,@productname,@price,@quantity,@totalcost)";

        com.Parameters.AddWithValue("@username", TextBox1.Text);
        com.Parameters.AddWithValue("@emailid", TextBox2.Text);

        com.Parameters.AddWithValue("@address", TextBox3.Text);
        com.Parameters.AddWithValue("@productname", TextBox4.Text);
        com.Parameters.AddWithValue("@price", TextBox7.Text);
        com.Parameters.AddWithValue("@quantity", TextBox5.Text);
        com.Parameters.AddWithValue("@totalcost", TextBox6.Text);
        

        Con.Open();

        int res = com.ExecuteNonQuery();
        Con.Close();

        if (res > 0)
        {
            //lblmsg.Text = "record inserted successfully";
            Label7.Text = "record inserted successfully";

        }
        else
        {
            //.Text = "could not insert record";
            Label7.Text = "could not insert";
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox6.Text = "";
            TextBox7.Text = "";

        }
      


    }
}
