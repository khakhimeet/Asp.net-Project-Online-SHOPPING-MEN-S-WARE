﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class login : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    SqlDataReader rd;
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString.ToString());
        con.Open();
        com = con.CreateCommand();
        com.CommandText = "select * from admin_login where adminname=@adminname and password=@password";
        com.Parameters.AddWithValue("@adminname", TextBox1.Text);
        com.Parameters.AddWithValue("@password", TextBox2.Text);
        rd = com.ExecuteReader();
        if (rd.HasRows)
        {
            Response.Redirect("Home.aspx");
        }
        con.Close();
    }

}
