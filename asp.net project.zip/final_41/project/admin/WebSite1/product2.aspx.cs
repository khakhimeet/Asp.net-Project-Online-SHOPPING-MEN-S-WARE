﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class product2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        if (e.CommandName == "Edit")
        {
            //Response.Write("edit" + e.CommandArgument.ToString());
            int pro_id = Convert.ToInt32(e.CommandArgument);
            SqlConnection con;
            SqlCommand com;
            SqlDataReader red;
            

            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            com = con.CreateCommand();

            com.CommandText = "select * from product where pro_id=@pro_id";
            com.Parameters.AddWithValue("@pro_id", pro_id);
            con.Open();
            red = com.ExecuteReader();
            red.Read();
            TextBox1.Text = red["pro_name"].ToString();
            TextBox2.Text = red["price"].ToString();
            red.Close();
            con.Close();
            Label4.Text = pro_id.ToString();
            DataList1.Enabled = false;

        }
        else if (e.CommandName == "Delete")
        {
            // Response.Write("Delete" + e.CommandArgument.ToString());
            int pro_id = Convert.ToInt32(e.CommandArgument);
            SqlCommand com;
            SqlConnection con;
            int r = 0;
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            com = con.CreateCommand();
            com.CommandText = "delete from product where pro_id=@pro_id";
            com.Parameters.AddWithValue("@pro_id", pro_id);
            con.Open();
            r = com.ExecuteNonQuery();
            con.Close();
            DataList1.DataBind();
        }
    }
    protected void sds_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        int pro_id = int.Parse(Label4.Text);
            SqlConnection con;
            SqlCommand com;
            int r = 0;
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            com = con.CreateCommand();
            com.CommandText = "update product set pro_name=@pro_name,price=@price where pro_id=@pro_id";
            com.Parameters.AddWithValue("@pro_id", pro_id);
            com.Parameters.AddWithValue("pro_name", TextBox1.Text.ToString());
            com.Parameters.AddWithValue("price", TextBox2.Text.ToString());
       
            con.Open();
            r = com.ExecuteNonQuery();
            con.Close();
            DataList1.DataBind();
            Panel1.Visible = false;
            DataList1.Enabled = true;
        }
    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void DataList1_SelectedIndexChanged1(object sender, EventArgs e)
    {

    }
}
