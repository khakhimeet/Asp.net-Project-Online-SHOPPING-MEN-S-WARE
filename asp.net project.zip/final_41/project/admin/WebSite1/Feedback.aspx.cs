﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class feedback : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {



    }
    protected void Button2_Click(object sender, EventArgs e)
    {
           }
    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        SqlConnection Con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand com = Con.CreateCommand();
        SqlDataReader red;
        com.CommandText = "selecet * from feedback where user_nm=@user_nm,Eid=@Eid,commect=@commect";

        com.Parameters.AddWithValue("@user_nm", TextBox1.Text);
        com.Parameters.AddWithValue("@Eid", TextBox2.Text);
        com.Parameters.AddWithValue("@commect", TextBox3.Text);

        red = com.ExecuteReader();
        Con.Open();
        TextBox1.Text = red["user_nm"].ToString();
        TextBox2.Text = red["Eid"].ToString();
        TextBox3.Text = red["commect"].ToString();
        red.Close();
        Con.Close();
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }

    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
