﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data;
using System.Data.SqlClient;

public partial class order : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection Con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand com = Con.CreateCommand();
        SqlDataReader red;
        com.CommandText = "selecet * from orders where orders_id=@orders_id,user_id=@user_id,pro_id=@pro_id,quantity=@quantity,total_amount=@total_amount";

        com.Parameters.AddWithValue("@orders_id",TextBox1.Text);
        com.Parameters.AddWithValue("@user_id",TextBox2.Text);
        com.Parameters.AddWithValue("@pro_id",TextBox3.Text);
        com.Parameters.AddWithValue("@quantity",TextBox4.Text);
        com.Parameters.AddWithValue("@total_amount",TextBox5.Text);

        red = com.ExecuteReader();
        Con.Open();
        TextBox1.Text = red["orders_id"].ToString();
        TextBox2.Text = red["user_id"].ToString();
        TextBox3.Text = red["pro_id"].ToString();
        TextBox4.Text = red["quantity"].ToString();
        TextBox5.Text = red["total_amount"].ToString();

        red.Close();
        Con.Close();
        Panel1.Visible = false;
        DataList1.Enabled = true;

    }


}
